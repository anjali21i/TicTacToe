import { Game } from "./Game";
import "./styles.css";

export default function App() {
  return <Game />;
}
